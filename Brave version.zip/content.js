(() => {

let enabled = true;

chrome.storage.sync.get(
    { enabled: true },
    (data) => {
        enabled = data.enabled;
    }
);

function getGoogleResult() {

    const containers = document.querySelectorAll("div.g");

    for (const c of containers) {

        const link = c.querySelector("a[href]");

        if (
            link &&
            link.href &&
            !link.href.includes("googleadservices") &&
            !link.href.includes("/aclk")
        ) {
            return link.href;
        }
    }

    return null;
}

function getBraveResult() {

    const links = document.querySelectorAll(
        ".snippet a[href], .heading a[href]"
    );

    for (const link of links) {

        if (
            link.href &&
            link.href.startsWith("http")
        ) {
            return link.href;
        }
    }

    return null;
}

function findResult() {

    const host = location.hostname;

    if (host.includes("google")) {
        return getGoogleResult();
    }

    if (host.includes("search.brave.com")) {
        return getBraveResult();
    }

    return null;
}

document.addEventListener(
    "keydown",
    (e) => {

        if (!enabled) return;

        if (e.key !== "Enter") return;

        const target = e.target;

        if (
            target.tagName === "INPUT" ||
            target.tagName === "TEXTAREA" ||
            target.isContentEditable
        ) {
            return;
        }

        const url = findResult();

        if (!url) {
            console.log("No result found");
            return;
        }

        location.href = url;
    },
    true
);

})();