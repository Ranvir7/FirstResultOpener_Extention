
Workflow:
1. Type a query in Google.
2. Press Enter normally.
3. Google shows search results.
4. Press Enter again anywhere on the results page.
5. The first search result opens.

Install:
1. Extract ZIP.
2. Open chrome://extensions
3. Enable Developer Mode.
4. Click Load Unpacked.
5. Select the extracted folder.
