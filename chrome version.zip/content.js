(() => {
  function getFirstResult() {
    return document.querySelector('#search a[href]');
  }

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter') return;

    const active = document.activeElement;
    if (
      active &&
      (active.tagName === 'INPUT' ||
       active.tagName === 'TEXTAREA' ||
       active.isContentEditable)
    ) {
      return; // allow normal search submission
    }

    const firstResult = getFirstResult();
    if (firstResult) {
      event.preventDefault();
      window.location.href = firstResult.href;
    }
  }, true);
})();